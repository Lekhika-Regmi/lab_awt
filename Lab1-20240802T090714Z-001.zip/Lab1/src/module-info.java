/**
 * 
 */
/**
 * @author Lenovo
 *
 */
module Lab1 {
	requires java.desktop;
}