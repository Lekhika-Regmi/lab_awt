package lab1;

import java.awt.*;
import java.awt.event.*;
import java.security.CryptoPrimitive;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class JavaLab1 extends Frame  implements ActionListener {

    /**
	 * 
	 */

	/**
     * @param args the command line arguments
     */
    public JavaLab1() {

        Frame f = new Frame();
        setSize(600, 400);
        setLayout(new BorderLayout()); 
      
        Panel pTop= new Panel();
        pTop.setLayout(new GridLayout(3,1));
        pTop.setSize(600,50);
        
        Panel pl= new Panel();
        pl.setLayout(new FlowLayout());
        pl.setSize(491,30);
      
        Label l = new Label("Rocky Woodfired Pizzas Management System");
        Font font = new Font("Arial", Font.BOLD, 18); 
        l.setFont(font);
        l.setAlignment(Label.LEFT);
        pl.add(l);
        pTop.add(pl);
        
        Panel cus= new Panel();
        cus.setLayout(new FlowLayout());
     
        Label customerNameLabel = new Label("Customer Name:");     
         TextField t = new TextField(20);

         
        cus.add(customerNameLabel);
        cus.add(t);
        
        pTop.add(cus);
     
        
        Panel p1= new Panel();
        p1.setLayout(new GridLayout(1,5));
        pl.setSize(400,20);
            
       
        
        Label toppingsLabel = new Label("Number of toppings:");
        TextField toppingsNum = new TextField();
         
        CheckboxGroup cbg = new CheckboxGroup();
        Checkbox c1 = new Checkbox("Small", cbg, false);

        Checkbox c2 = new Checkbox("Medium", cbg, false);

        Checkbox c3 = new Checkbox("Large", cbg, false);

      
         pl.add(l);
        
        p1.add(toppingsLabel);

        p1.add(toppingsNum);

        p1.add(c1);

        p1.add(c2);

        p1.add(c3);
       
        pTop.add(p1);
       
        setTitle("Lab 1");
        
        
        Panel p2= new Panel();
        p2.setSize(490,300);
        TextArea descTxtArea = new TextArea();
        descTxtArea.setRows(15);
        p2.add(descTxtArea);
      
        
        
        Panel p3= new Panel();
        p3.setSize(490,10);
        Button btnEnter= new Button("Enter");
        Button btnDisplay= new Button("Display");
        Button btnSearch= new Button("Search");
        Button btnExit= new Button("Exit");
        btnEnter.setSize(100,10);
        btnDisplay.setSize(100,10);
        btnSearch.setSize(100,10);
        btnExit.setSize(100,10);
        
        btnEnter.addActionListener( this);
        
        
        
        p3.add(btnEnter);
        p3.add(btnDisplay);
        p3.add(btnSearch);
        p3.add(btnExit);
        
        
        
        add(pTop,BorderLayout.NORTH);
        add(p2,BorderLayout.CENTER);
        add(p3,BorderLayout.SOUTH);
        
        
        
        
        
        setVisible(true);
        
        
        
        
        
        
 addWindowListener (new WindowAdapter() {    
            public void windowClosing (WindowEvent e) {    
                dispose();    
            }    
        });  
 
 
    }

    public static void main(String[] args) {
        // TODO code application logic here
        JavaLab1 j = new JavaLab1();
    }

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}

}



